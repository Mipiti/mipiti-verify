#!/usr/bin/env bash
# Checks every certificate and proof of this bundle again, with the commands
# the platform ran. Needs a Java 21 runtime, the Apalache release and the tlapm
# build manifest.json names (tools), and Z3 on PATH beside tlapm.
#   APALACHE_JAR=/path/to/apalache.jar TLAPM=/path/to/tlapm bash recheck.sh
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
: "${APALACHE_JAR:?set APALACHE_JAR to the jar of the pinned Apalache release}"
TLAPM="${TLAPM:-tlapm}"
failed=0

# FlagStays: certificate dab4a5980000c7d82189f5200b4be80181813f30a05da9c010f913352aae2179
WORK=$(mktemp -d)
cp "$HERE/modules/dab4a5980000c7d82189f5200b4be80181813f30a05da9c010f913352aae2179/"*.tla "$WORK/"
ok=1
(cd "$WORK" && java -Xss64m -Djava.io.tmpdir="$WORK" -cp "$APALACHE_JAR" at.forsyte.apalache.tla.Tool check --out-dir="$WORK"/out --cinit=CInit --no-deadlock --init=Init --inv=IndInv --length=0 Cert_030f7e6c67_p_and_type.tla) > "$WORK/init.log" 2>&1
grep -q 'EXITCODE: OK' "$WORK/init.log" || { ok=0; echo "certificate dab4a5980000c7d82189f5200b4be80181813f30a05da9c010f913352aae2179: the init check did not hold (log: $WORK/init.log)"; }
(cd "$WORK" && java -Xss64m -Djava.io.tmpdir="$WORK" -cp "$APALACHE_JAR" at.forsyte.apalache.tla.Tool check --out-dir="$WORK"/out --cinit=CInit --no-deadlock --init=InitInv --inv=IndInv --length=1 Cert_030f7e6c67_p_and_type.tla) > "$WORK/step.log" 2>&1
grep -q 'EXITCODE: OK' "$WORK/step.log" || { ok=0; echo "certificate dab4a5980000c7d82189f5200b4be80181813f30a05da9c010f913352aae2179: the step check did not hold (log: $WORK/step.log)"; }
(cd "$WORK" && java -Xss64m -Djava.io.tmpdir="$WORK" -cp "$APALACHE_JAR" at.forsyte.apalache.tla.Tool check --out-dir="$WORK"/out --cinit=CInit --no-deadlock --init=InitInv --inv=Prop --length=1 Cert_030f7e6c67_p_and_type.tla) > "$WORK/property.log" 2>&1
grep -q 'EXITCODE: OK' "$WORK/property.log" || { ok=0; echo "certificate dab4a5980000c7d82189f5200b4be80181813f30a05da9c010f913352aae2179: the property check did not hold (log: $WORK/property.log)"; }
[ "$ok" = 1 ] && echo "certificate dab4a5980000c7d82189f5200b4be80181813f30a05da9c010f913352aae2179: holds" || failed=1

# FlagStays: proof 6c454b3a30533c5d1bafc63af9802e01101ec192b5d179d3425d9ef6a0c3bae1
WORK=$(mktemp -d)
cp "$HERE/proofs/6c454b3a30533c5d1bafc63af9802e01101ec192b5d179d3425d9ef6a0c3bae1/"*.tla "$WORK/"
if (cd "$WORK" && "$TLAPM" --strict --cache-dir "$WORK"/cache --method smt:600,zenon,ls4 --solver 'z3 -smt2 -v:0 AUTO_CONFIG=false smt.MBQI=true rlimit=60000000 "$file"' --stretch 4 --toolbox 0 0 Cert_030f7e6c67_proof.tla) > "$WORK/tlapm.log" 2>&1 && ! grep -q "@!!status:failed" "$WORK/tlapm.log"; then
  echo "proof 6c454b3a30533c5d1bafc63af9802e01101ec192b5d179d3425d9ef6a0c3bae1: closed"
else
  failed=1; echo "proof 6c454b3a30533c5d1bafc63af9802e01101ec192b5d179d3425d9ef6a0c3bae1: did not close (log: $WORK/tlapm.log)"
fi

[ "$failed" = 0 ] && echo "every certificate and proof checks again" || { echo "a certificate or proof did not check again"; exit 1; }
