Design proof bundle
===================

Model fixture-model, version 1.

What it states: for every obligation the behavioural analysis linked to a live
control objective, under the empty control set, what decides it. An obligation
is CERTIFIED where Apalache's three checks of its module held, PROVED where a
TLAPS proof of it closed as well, TO_JUDGE where the analysis found a possible
threat, could not decide, or holds without a certificate (the judge and the
controls decide those), and NOT_EVALUATED where its objective is still being
computed or past the enumeration bound.

What it does not state: that the system is secure, or that the behavioural
model is the system. A certificate is about the module, which is the
behavioural model as confirmed (manifest.json, status), within the scope
recorded with each certificate.

Coverage: 1 of 2 obligations certified (1 also proved); 1 to the judge; 0 not evaluated.

Checking it: mipiti-verify design-bundle <this archive> checks the signature,
the key against the platform's JWKS, every file against manifest.json, the
coverage against obligations.json, and that each certificate and proof is
about its module and its claim; add --recheck to run every certificate's
three Apalache checks and every proof's tlapm run again, with commands it
builds itself (never recheck.sh), in the pinned tools image or with your
own tools (--tools local). --sample K --seed S re-checks K of them, picked
by a seed you choose; --jobs N runs N at once.

By hand: write signature.json's public_key_pem to key.pem and its
signature_der_b64, base64-decoded, to sig.der, then verify the signature over
manifest.json (openssl dgst -sha256 -verify key.pem -signature sig.der
manifest.json); check that the key's fingerprint is the platform's (its JWKS),
check each file's SHA-256 against manifest.json, then run recheck.sh.
