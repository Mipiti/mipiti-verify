---- MODULE Cert_030f7e6c67_p_and_type ----
EXTENDS Cert_030f7e6c67, Apalache

CInit == H = 0 /\ Inst = 1 /\ Snap = 2 /\ Skew = 1 /\ NSec = 1 /\ Lo_0_0 = 0 /\ Hi_0_0 = 2

\* candidate revision 4: p_and_type
\* @type: Set($secret);
SecretU == {}
\* @type: Set($secret);
ObsU == ({NoSecret})
\* @type: ($held2) => Bool;
HeldOK2(q) == q.p \in {[c |-> 1, i |-> 0]} /\ q.x0 \in {0} /\ q.v0 \in BOOLEAN /\ q.t0 \in [ex: {TRUE}, f0: Lo_0_0..Hi_0_0, f1: BOOLEAN]
Inv_1 == now \in 0..H
Inv_2 == e0 \in [{0} -> [ex: {TRUE}, f0: Lo_0_0..Hi_0_0, f1: BOOLEAN]]
Inv_3 == e1 \in [{0} -> [ex: {TRUE}, f0: BOOLEAN]]
Inv_4 == obs \in [Principals -> SUBSET (ObsU \ {NoSecret})]
Inv_5 == pool \in [0..(NSec - 1) -> 0..0]
Inv_6 == \A q \in DOMAIN fl2 : HeldOK2(q) /\ fl2[q] \in 1..Inst
Inv_7 == IsFiniteSet(DOMAIN fl2) /\ FlCard(fl2) <= Inst
IndInv ==
  /\ Inv_1
  /\ Inv_2
  /\ Inv_3
  /\ Inv_4
  /\ Inv_5
  /\ Inv_6
  /\ Inv_7
Prop == ClaimStep_0
Assign ==
  /\ now \in 0..H
  /\ e0 \in [{0} -> [ex: {TRUE}, f0: Lo_0_0..Hi_0_0, f1: BOOLEAN]]
  /\ e1 \in [{0} -> [ex: {TRUE}, f0: BOOLEAN]]
  /\ obs \in [Principals -> SUBSET (ObsU \ {NoSecret})]
  /\ pool \in [0..(NSec - 1) -> 0..0]
  /\ fl2 = Gen(1)
InitInv == Assign /\ IndInv
====
