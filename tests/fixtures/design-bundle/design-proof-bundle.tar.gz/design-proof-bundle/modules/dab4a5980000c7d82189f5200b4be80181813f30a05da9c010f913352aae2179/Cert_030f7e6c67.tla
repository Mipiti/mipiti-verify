---- MODULE Cert_030f7e6c67 ----
EXTENDS Integers, Sequences, FiniteSets

CONSTANTS
    \* @type: Int;
    H,
    \* @type: Int;
    Inst,
    \* @type: Int;
    Snap,
    \* @type: Int;
    Skew,
    \* @type: Int;
    NSec,
    \* @type: Int;
    Lo_0_0,
    \* @type: Int;
    Hi_0_0
ASSUME Asm_H == H \in Nat
ASSUME Asm_Inst == Inst \in Nat
ASSUME Asm_Snap == Snap \in Nat
ASSUME Asm_Skew == Skew \in Nat
ASSUME Asm_NSec == NSec \in Nat
ASSUME Asm_Lo_0_0 == Lo_0_0 \in Int
ASSUME Asm_Hi_0_0 == Hi_0_0 \in Int /\ Lo_0_0 <= Hi_0_0

VARIABLES
    \* @type: Int;
    now,
    \* @type: Int -> $rec0;
    e0,
    \* @type: Int -> $rec1;
    e1,
    \* @type: $held2 -> Int;
    fl2,
    \* @type: $principal -> Set($secret);
    obs,
    \* @type: Int -> Int;
    pool
vars == <<now, e0, e1, fl2, obs, pool>>

\* @typeAlias: secret = { k: Set(Int), s: Seq(<<Int, Int>>) };
\* @typeAlias: principal = { c: Int, i: Int };
\* @typeAlias: rec0 = { ex: Bool, f0: Int, f1: Bool };
\* @typeAlias: rec1 = { ex: Bool, f0: Bool };
\* @typeAlias: held2 = { p: $principal, t0: $rec0, v0: Bool, x0: Int };
Cert_030f7e6c67_aliases == TRUE

\* @type: (Set(Int)) => Int;
Min(S) == CHOOSE t \in S : \A u \in S : t <= u
Clamp(v) == (IF v < 0 THEN 0 ELSE (IF v > H THEN H ELSE v))
Cap2(n) == (IF n > 2 THEN 2 ELSE n)
\* @type: $secret;
NoSecret == [k |-> {}, s |-> << <<0, 0>> >>]
\* @type: (Int) => $secret;
Tok(t) == [k |-> {t}, s |-> << <<1, t>> >>]
\* @type: ($secret) => Set(Int);
Toks(v) == v.k
\* @type: ($principal -> Set($secret), Set($principal), $secret) => ($principal -> Set($secret));
ObsAdd(o, W, v) == [q \in DOMAIN o |-> (IF q \in W /\ v # NoSecret THEN o[q] \cup {v} ELSE o[q])]
Free == {t \in 0..(NSec - 1) : pool[t] = 0}
Known == UNION {obs[q] : q \in DOMAIN obs}
\* @type: Int -> Set(Int);
TokLab == [o \in 0..0 |-> {}]
\* @type: ($secret) => Set(Int);
Lab(v) == UNION {TokLab[pool[t]] : t \in Toks(v)}
\* @type: a -> Int;
FlNone == [y \in {} |-> 0]
\* @type: (a -> Int, a) => (a -> Int);
FlAdd(B, r) == [y \in DOMAIN B \cup {r} |-> (IF y \in DOMAIN B THEN B[y] ELSE 0) + (IF y = r THEN 1 ELSE 0)]
\* @type: (a -> Int, a) => (a -> Int);
FlSub(B, r) == [y \in {z \in DOMAIN B : z # r \/ B[z] > 1} |-> (IF y = r THEN B[y] - 1 ELSE B[y])]
\* @type: (a -> Int) => Int;
FlCard(B) == Cardinality({w \in (DOMAIN B) \X (1..Inst) : w[2] <= B[w[1]]})
\* @type: Set($principal);
Principals == {[c |-> 1, i |-> 0]}
\* @type: $rec0;
IR0 == [ex |-> TRUE, f0 |-> Lo_0_0, f1 |-> FALSE]
\* @type: $rec1;
IR1 == [ex |-> TRUE, f0 |-> FALSE]

Init ==
  /\ now = 0
  /\ e0 = [x \in {0} |-> IR0]
  /\ e1 = [x \in {0} |-> IR1]
  /\ fl2 = FlNone
  /\ obs = [q \in Principals |-> {}]
  /\ pool = [t \in 0..(NSec - 1) |-> 0]

A0 ==
  \E p \in {[c |-> 1, i |-> 0]} :
    /\ LET x0 == 0
           v0 == (e0[0].f0 + 1)
           t0 == e0[x0]
       IN  /\ (e0[0].f0 < 2)
           /\ v0 \in Lo_0_0..Hi_0_0
           /\ e0' = [e0 EXCEPT ![x0].f0 = v0]
           /\ obs' = obs
           /\ pool' = pool
           /\ UNCHANGED <<now, e1, fl2>>

A1 ==
  \E p \in {[c |-> 1, i |-> 0]} :
    /\ LET x0 == 0
           v0 == TRUE
           t0 == e1[x0]
       IN  /\ (e0[0].f0 = 2)
           /\ e1' = [e1 EXCEPT ![x0].f0 = v0]
           /\ obs' = obs
           /\ pool' = pool
           /\ UNCHANGED <<now, e0, fl2>>

R2 ==
  \E p \in {[c |-> 1, i |-> 0]} :
    /\ LET x0 == 0
           v0 == TRUE
           t0 == e0[x0]
       IN  /\ FlCard(fl2) < Inst
           /\ TRUE
           /\ fl2' = FlAdd(fl2, [p |-> p, x0 |-> x0, v0 |-> v0, t0 |-> t0])
           /\ obs' = obs
           /\ pool' = pool
           /\ UNCHANGED <<now, e0, e1>>

W2 ==
  \E q \in DOMAIN fl2 :
    /\ fl2' = FlSub(fl2, q)
    /\ obs' = obs
    /\ ((e0' = [e0 EXCEPT ![q.x0].f1 = q.v0]) \/ (e0' = [e0 EXCEPT ![q.x0] = [q.t0 EXCEPT !.f1 = (IF q.x0 = q.x0 THEN q.v0 ELSE @)]]))
    /\ UNCHANGED <<now, e1, pool>>

S2 ==
  \E q \in DOMAIN fl2 :
    /\ fl2' = FlSub(fl2, q)
    /\ UNCHANGED <<now, e0, e1, obs, pool>>

Tick ==
  /\ now < H
  /\ now' = now + 1
  /\ UNCHANGED <<e0, e1, fl2, obs, pool>>

Next ==
  \/ A0
  \/ A1
  \/ R2
  \/ W2
  \/ S2
  \/ Tick

Spec == Init /\ [][Next]_vars
FairSpec == Spec /\ WF_vars(A0) /\ WF_vars(A1) /\ WF_vars(R2) /\ WF_vars(W2)

ClaimStep_0 == \A x \in {0} : (e1[x].ex /\ e1[x].f0 = TRUE) => (e1'[x].ex => e1'[x].f0 = TRUE)
Claim_0 == [][ClaimStep_0]_vars
====
