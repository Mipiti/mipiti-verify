---- MODULE Cert_030f7e6c67_proof ----
EXTENDS Cert_030f7e6c67, FiniteSetTheorems, TLAPS

\* proof revision 2

\* candidate revision 4: p_and_type
\* @type: Set($secret);
SecretU == {}
\* @type: Set($secret);
ObsU == ({NoSecret})
\* @type: ($held2) => Bool;
HeldOK2(q) == q.p \in {[c |-> 1, i |-> 0]} /\ q.x0 \in {0} /\ q.v0 \in BOOLEAN /\ q.t0 \in [ex: {TRUE}, f0: Lo_0_0..Hi_0_0, f1: BOOLEAN]
Inv_1 == now \in 0..H
Inv_2 == e0 \in [{0} -> [ex: {TRUE}, f0: Lo_0_0..Hi_0_0, f1: BOOLEAN]]
Inv_3 == e1 \in [{0} -> [ex: {TRUE}, f0: BOOLEAN]]
Inv_4 == obs \in [Principals -> SUBSET (ObsU \ {NoSecret})]
Inv_5 == pool \in [0..(NSec - 1) -> 0..0]
Inv_6 == \A q \in DOMAIN fl2 : HeldOK2(q) /\ fl2[q] \in 1..Inst
Inv_7 == IsFiniteSet(DOMAIN fl2) /\ FlCard(fl2) <= Inst
IndInv ==
  /\ Inv_1
  /\ Inv_2
  /\ Inv_3
  /\ Inv_4
  /\ Inv_5
  /\ Inv_6
  /\ Inv_7
Prop == ClaimStep_0

BagOK(B) == IsFiniteSet(DOMAIN B) /\ \A y \in DOMAIN B : B[y] \in 1..Inst
FlSet(B) == {w \in (DOMAIN B) \X (1..Inst) : w[2] <= B[w[1]]}

LEMMA FlNoneFacts == DOMAIN FlNone = {}
  BY DEF FlNone

LEMMA FlAddFacts ==
  \A B, r : /\ DOMAIN FlAdd(B, r) = DOMAIN B \cup {r}
            /\ \A y \in DOMAIN FlAdd(B, r) :
                 FlAdd(B, r)[y] = (IF y \in DOMAIN B THEN B[y] ELSE 0) + (IF y = r THEN 1 ELSE 0)
  BY DEF FlAdd

LEMMA FlSubFacts ==
  \A B, q : /\ DOMAIN FlSub(B, q) = {z \in DOMAIN B : z # q \/ B[z] > 1}
            /\ \A y \in DOMAIN FlSub(B, q) : FlSub(B, q)[y] = IF y = q THEN B[y] - 1 ELSE B[y]
  BY DEF FlSub

LEMMA FlSetPair == \A B : \A w \in FlSet(B) : \E a, b : w = <<a, b>>
  BY DEF FlSet

LEMMA FlSetMem ==
  \A B, a, b : <<a, b>> \in FlSet(B) <=> a \in DOMAIN B /\ b \in 1..Inst /\ b <= B[a]
  BY DEF FlSet

LEMMA FlSetFinite == \A B : IsFiniteSet(DOMAIN B) => IsFiniteSet(FlSet(B))
<1> SUFFICES ASSUME NEW B, IsFiniteSet(DOMAIN B) PROVE IsFiniteSet(FlSet(B))
  OBVIOUS
<1>1. IsFiniteSet(1..Inst) BY Asm_Inst, FS_Interval
<1>2. IsFiniteSet((DOMAIN B) \X (1..Inst)) BY <1>1, FS_Product
<1> QED BY <1>2, FS_Subset DEF FlSet

LEMMA BagCard ==
  \A B : IsFiniteSet(DOMAIN B) => FlCard(B) = Cardinality(FlSet(B)) /\ FlCard(B) \in Nat
  BY FlSetFinite, FS_CardinalityType DEF FlCard, FlSet

LEMMA BagCount == \A B : BagOK(B) => \A y \in DOMAIN B : B[y] <= FlCard(B)
<1> SUFFICES ASSUME NEW B, BagOK(B), NEW y \in DOMAIN B PROVE B[y] <= FlCard(B)
  OBVIOUS
<1>1. B[y] \in 1..Inst BY DEF BagOK
<1>2. {y} \X (1..B[y]) \subseteq FlSet(B)
  <2> SUFFICES ASSUME NEW a \in {y}, NEW b \in 1..B[y] PROVE <<a, b>> \in FlSet(B)
    OBVIOUS
  <2> QED BY <1>1, Asm_Inst, FlSetMem
<1>3. IsFiniteSet({y}) /\ Cardinality({y}) = 1 BY FS_Singleton
<1>4. IsFiniteSet(1..B[y]) /\ Cardinality(1..B[y]) = B[y] BY <1>1, Asm_Inst, FS_Interval
<1>5. Cardinality({y} \X (1..B[y])) = B[y] BY <1>1, <1>3, <1>4, Asm_Inst, FS_Product
<1>6. IsFiniteSet(FlSet(B)) BY FlSetFinite DEF BagOK
<1> QED BY <1>2, <1>5, <1>6, FS_Subset, BagCard DEF BagOK

LEMMA BagNone == BagOK(FlNone) /\ FlCard(FlNone) = 0
<1>1. DOMAIN FlNone = {} BY FlNoneFacts
<1>2. FlSet(FlNone) = {} BY <1>1 DEF FlSet
<1>3. IsFiniteSet(DOMAIN FlNone) BY <1>1, FS_EmptySet
<1> QED BY <1>1, <1>2, <1>3, BagCard, FS_EmptySet DEF BagOK

LEMMA BagAdd ==
  \A B, r : BagOK(B) /\ FlCard(B) < Inst =>
              BagOK(FlAdd(B, r)) /\ FlCard(FlAdd(B, r)) <= FlCard(B) + 1
<1> SUFFICES ASSUME NEW B, NEW r, BagOK(B), FlCard(B) < Inst
             PROVE BagOK(FlAdd(B, r)) /\ FlCard(FlAdd(B, r)) <= FlCard(B) + 1
  OBVIOUS
<1> DEFINE N == FlAdd(B, r)
<1> DEFINE k == IF r \in DOMAIN B THEN B[r] + 1 ELSE 1
<1>1. DOMAIN N = DOMAIN B \cup {r} BY FlAddFacts
<1>2. \A y \in DOMAIN N : N[y] = (IF y \in DOMAIN B THEN B[y] ELSE 0) + (IF y = r THEN 1 ELSE 0)
  BY FlAddFacts
<1>3. FlCard(B) \in Nat BY BagCard DEF BagOK
<1>4. r \in DOMAIN B => B[r] <= FlCard(B) BY BagCount
<1>5. k \in 1..Inst BY <1>3, <1>4, Asm_Inst DEF BagOK
<1>6. \A y \in DOMAIN N : N[y] \in 1..Inst BY <1>1, <1>2, <1>5, Asm_Inst DEF BagOK
<1>7. IsFiniteSet(DOMAIN N) BY <1>1, FS_AddElement DEF BagOK
<1>8. FlSet(N) \subseteq FlSet(B) \cup {<<r, k>>}
  <2> SUFFICES ASSUME NEW w \in FlSet(N) PROVE w \in FlSet(B) \cup {<<r, k>>}
    OBVIOUS
  <2>1. PICK a, b : w = <<a, b>> BY FlSetPair
  <2>2. a \in DOMAIN N /\ b \in 1..Inst /\ b <= N[a] BY <2>1, FlSetMem
  <2>3. CASE a # r
    <3>1. a \in DOMAIN B BY <2>2, <2>3, <1>1
    <3>2. N[a] = B[a] BY <2>2, <2>3, <3>1, <1>2, Asm_Inst DEF BagOK
    <3> QED BY <2>1, <2>2, <3>1, <3>2, FlSetMem
  <2>4. CASE a = r /\ b = k BY <2>1, <2>4
  <2>5. CASE a = r /\ b # k
    <3>1. N[r] = (IF r \in DOMAIN B THEN B[r] ELSE 0) + 1 BY <2>2, <2>5, <1>2
    <3>2. r \in DOMAIN B
      <4>1. CASE r \notin DOMAIN B BY <2>2, <2>5, <3>1, <4>1, Asm_Inst
      <4> QED BY <4>1
    <3>3. B[r] \in 1..Inst BY <3>2 DEF BagOK
    <3>4. b <= B[r] BY <2>2, <2>5, <3>1, <3>2, <3>3, Asm_Inst
    <3> QED BY <2>1, <2>2, <2>5, <3>2, <3>4, FlSetMem
  <2> QED BY <2>3, <2>4, <2>5
<1>9. IsFiniteSet(FlSet(B)) BY FlSetFinite DEF BagOK
<1>10. /\ IsFiniteSet(FlSet(B) \cup {<<r, k>>})
       /\ Cardinality(FlSet(B) \cup {<<r, k>>}) <= Cardinality(FlSet(B)) + 1
  <2>1. Cardinality(FlSet(B)) \in Nat BY <1>9, FS_CardinalityType
  <2> QED BY <1>9, <2>1, FS_AddElement
<1>11. FlCard(N) <= FlCard(B) + 1
  <2>1. IsFiniteSet(FlSet(N)) /\ Cardinality(FlSet(N)) <= Cardinality(FlSet(B) \cup {<<r, k>>})
    BY <1>8, <1>10, FS_Subset
  <2>2. FlCard(N) = Cardinality(FlSet(N)) BY <1>7, BagCard
  <2>3. FlCard(B) = Cardinality(FlSet(B)) BY BagCard DEF BagOK
  <2>4. /\ Cardinality(FlSet(N)) \in Nat
        /\ Cardinality(FlSet(B) \cup {<<r, k>>}) \in Nat
        /\ Cardinality(FlSet(B)) \in Nat
    BY <1>9, <1>10, <2>1, FS_CardinalityType
  <2> QED BY <1>10, <2>1, <2>2, <2>3, <2>4
<1> QED BY <1>6, <1>7, <1>11 DEF BagOK

LEMMA BagSub ==
  \A B, q : BagOK(B) /\ q \in DOMAIN B =>
              BagOK(FlSub(B, q)) /\ FlCard(FlSub(B, q)) <= FlCard(B)
<1> SUFFICES ASSUME NEW B, NEW q, BagOK(B), q \in DOMAIN B
             PROVE BagOK(FlSub(B, q)) /\ FlCard(FlSub(B, q)) <= FlCard(B)
  OBVIOUS
<1> DEFINE N == FlSub(B, q)
<1>1. DOMAIN N = {z \in DOMAIN B : z # q \/ B[z] > 1} BY FlSubFacts
<1>2. \A y \in DOMAIN N : N[y] = IF y = q THEN B[y] - 1 ELSE B[y] BY FlSubFacts
<1>3. \A y \in DOMAIN N : N[y] \in 1..Inst
  <2> SUFFICES ASSUME NEW y \in DOMAIN N PROVE N[y] \in 1..Inst
    OBVIOUS
  <2>1. y \in DOMAIN B /\ (y # q \/ B[y] > 1) BY <1>1
  <2>2. B[y] \in 1..Inst BY <2>1 DEF BagOK
  <2>3. CASE y = q
    <3>1. N[y] = B[y] - 1 BY <1>2, <2>3
    <3> QED BY <2>1, <2>2, <2>3, <3>1, Asm_Inst
  <2>4. CASE y # q
    <3>1. N[y] = B[y] BY <1>2, <2>4
    <3> QED BY <2>2, <3>1
  <2> QED BY <2>3, <2>4
<1>4. IsFiniteSet(DOMAIN N) BY <1>1, FS_Subset DEF BagOK
<1>5. FlSet(N) \subseteq FlSet(B)
  <2> SUFFICES ASSUME NEW w \in FlSet(N) PROVE w \in FlSet(B)
    OBVIOUS
  <2>1. PICK a, b : w = <<a, b>> BY FlSetPair
  <2>2. a \in DOMAIN N /\ b \in 1..Inst /\ b <= N[a] BY <2>1, FlSetMem
  <2>3. a \in DOMAIN B /\ b <= B[a] BY <2>2, <1>1, <1>2, <1>3, Asm_Inst DEF BagOK
  <2> QED BY <2>1, <2>2, <2>3, FlSetMem
<1>6. IsFiniteSet(FlSet(B)) BY FlSetFinite DEF BagOK
<1>7. IsFiniteSet(FlSet(N)) /\ Cardinality(FlSet(N)) <= Cardinality(FlSet(B))
  BY <1>5, <1>6, FS_Subset
<1> QED BY <1>3, <1>4, <1>7, BagCard DEF BagOK

THEOREM InitHolds == Init => IndInv
<1> SUFFICES ASSUME Init PROVE IndInv
  OBVIOUS
<1>1. Inv_1
  BY Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Init, Inv_1, IR0, IR1, Principals, IndInv
<1>2. Inv_2
  BY Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Init, Inv_2, IR0, IR1, Principals, IndInv
<1>3. Inv_3
  BY Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Init, Inv_3, IR0, IR1, Principals, IndInv
<1>4. Inv_4
  BY Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Init, Inv_4, IR0, IR1, Principals, ObsU, NoSecret, IndInv
<1>5. Inv_5
  BY Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Init, Inv_5, IR0, IR1, Principals, IndInv
<1>6. Inv_6
  BY Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, FlNoneFacts, BagNone DEF Init, Inv_6, IR0, IR1, Principals, HeldOK2, BagOK, IndInv
<1>7. Inv_7
  BY Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, BagCard, FlNoneFacts, BagNone DEF Init, Inv_7, IR0, IR1, Principals, BagOK, IndInv
<1> QED BY <1>1, <1>2, <1>3, <1>4, <1>5, <1>6, <1>7 DEF IndInv

THEOREM StepHolds == IndInv /\ [Next]_vars => IndInv'
<1> SUFFICES ASSUME IndInv, [Next]_vars PROVE IndInv'
  OBVIOUS
<1>1. CASE A0
  <2>1. Inv_1'
    BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Inv_1, IndInv
  <2>2. Inv_2'
    BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_5, IndInv
  <2>3. Inv_3'
    BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Inv_3, IndInv
  <2>4. Inv_4'
    BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Inv_4, Principals, ObsU, NoSecret, Inv_2, Inv_5, IndInv
  <2>5. Inv_5'
    BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Inv_5, Inv_2, Inv_4, Principals, ObsU, NoSecret, IndInv
  <2>6. Inv_6'
    BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Inv_6, HeldOK2, IndInv
  <2>7. Inv_7'
    BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Inv_7, IndInv
  <2> QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7 DEF IndInv
<1>2. CASE A1
  <2>1. Inv_1'
    BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Inv_1, IndInv
  <2>2. Inv_2'
    BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Inv_2, IndInv
  <2>3. Inv_3'
    BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Inv_3, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_5, IndInv
  <2>4. Inv_4'
    BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Inv_4, Principals, ObsU, NoSecret, Inv_2, Inv_3, Inv_5, IndInv
  <2>5. Inv_5'
    BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Inv_5, Inv_2, Inv_3, Inv_4, Principals, ObsU, NoSecret, IndInv
  <2>6. Inv_6'
    BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Inv_6, HeldOK2, IndInv
  <2>7. Inv_7'
    BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Inv_7, IndInv
  <2> QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7 DEF IndInv
<1>3. CASE R2
  <2>1. Inv_1'
    BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF R2, Inv_1, IndInv
  <2>2. Inv_2'
    BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF R2, Inv_2, IndInv
  <2>3. Inv_3'
    BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF R2, Inv_3, IndInv
  <2>4. Inv_4'
    BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF R2, Inv_4, Principals, ObsU, NoSecret, Inv_2, Inv_5, Inv_6, HeldOK2, Inv_7, IndInv
  <2>5. Inv_5'
    BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF R2, Inv_5, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_6, HeldOK2, Inv_7, IndInv
  <2>6. Inv_6'
    BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, FlAddFacts, BagAdd, BagCount, BagCard DEF R2, Inv_6, HeldOK2, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_5, Inv_7, BagOK, IndInv
  <2>7. Inv_7'
    BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, FlAddFacts, BagAdd, BagCount, BagCard DEF R2, Inv_7, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_5, Inv_6, HeldOK2, BagOK, IndInv
  <2> QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7 DEF IndInv
<1>4. CASE W2
  <2>1. Inv_1'
    BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF W2, Inv_1, IndInv
  <2>2. Inv_2'
    BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF W2, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_6, HeldOK2, Inv_7, IndInv
  <2>3. Inv_3'
    BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF W2, Inv_3, IndInv
  <2>4. Inv_4'
    BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF W2, Inv_4, Principals, ObsU, NoSecret, Inv_2, Inv_6, HeldOK2, Inv_7, IndInv
  <2>5. Inv_5'
    BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF W2, Inv_5, IndInv
  <2>6. Inv_6'
    BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, BagCard, FlSubFacts, BagSub DEF W2, Inv_6, HeldOK2, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_7, BagOK, IndInv
  <2>7. Inv_7'
    BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, BagCard, FlSubFacts, BagSub DEF W2, Inv_7, Inv_2, Inv_4, Principals, ObsU, NoSecret, Inv_6, HeldOK2, BagOK, IndInv
  <2> QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7 DEF IndInv
<1>5. CASE S2
  <2>1. Inv_1'
    BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF S2, Inv_1, IndInv
  <2>2. Inv_2'
    BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF S2, Inv_2, IndInv
  <2>3. Inv_3'
    BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF S2, Inv_3, IndInv
  <2>4. Inv_4'
    BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF S2, Inv_4, Principals, ObsU, NoSecret, IndInv
  <2>5. Inv_5'
    BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF S2, Inv_5, IndInv
  <2>6. Inv_6'
    BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, BagCard, FlSubFacts, BagSub DEF S2, Inv_6, HeldOK2, Inv_7, BagOK, IndInv
  <2>7. Inv_7'
    BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0, BagCard, FlSubFacts, BagSub DEF S2, Inv_7, Inv_6, HeldOK2, BagOK, IndInv
  <2> QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7 DEF IndInv
<1>6. CASE Tick
  <2>1. Inv_1'
    BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Inv_1, IndInv
  <2>2. Inv_2'
    BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Inv_2, IndInv
  <2>3. Inv_3'
    BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Inv_3, IndInv
  <2>4. Inv_4'
    BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Inv_4, Principals, ObsU, NoSecret, IndInv
  <2>5. Inv_5'
    BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Inv_5, IndInv
  <2>6. Inv_6'
    BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Inv_6, HeldOK2, IndInv
  <2>7. Inv_7'
    BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Inv_7, IndInv
  <2> QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7 DEF IndInv
<1>7. CASE UNCHANGED vars
  <2>1. Inv_1'
    BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Inv_1, IndInv
  <2>2. Inv_2'
    BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Inv_2, IndInv
  <2>3. Inv_3'
    BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Inv_3, IndInv
  <2>4. Inv_4'
    BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Inv_4, Principals, ObsU, NoSecret, IndInv
  <2>5. Inv_5'
    BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Inv_5, IndInv
  <2>6. Inv_6'
    BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Inv_6, HeldOK2, IndInv
  <2>7. Inv_7'
    BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Inv_7, IndInv
  <2> QED BY <2>1, <2>2, <2>3, <2>4, <2>5, <2>6, <2>7 DEF IndInv
<1> QED BY <1>1, <1>2, <1>3, <1>4, <1>5, <1>6, <1>7 DEF Next

THEOREM PropHolds == IndInv /\ [Next]_vars => [Prop]_vars
<1> SUFFICES ASSUME IndInv, [Next]_vars PROVE [Prop]_vars
  OBVIOUS
<1>1. CASE A0
  BY <1>1, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A0, Prop, ClaimStep_0, IndInv
<1>2. CASE A1
  BY <1>2, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF A1, Prop, ClaimStep_0, Inv_2, Inv_3, Inv_4, Principals, ObsU, NoSecret, Inv_5, IndInv
<1>3. CASE R2
  BY <1>3, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF R2, Prop, ClaimStep_0, IndInv
<1>4. CASE W2
  BY <1>4, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF W2, Prop, ClaimStep_0, IndInv
<1>5. CASE S2
  BY <1>5, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF S2, Prop, ClaimStep_0, IndInv
<1>6. CASE Tick
  BY <1>6, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF Tick, Prop, ClaimStep_0, IndInv
<1>7. CASE UNCHANGED vars
  BY <1>7, Asm_H, Asm_Inst, Asm_Snap, Asm_Skew, Asm_NSec, Asm_Lo_0_0, Asm_Hi_0_0 DEF vars, Prop, ClaimStep_0, IndInv
<1> QED BY <1>1, <1>2, <1>3, <1>4, <1>5, <1>6, <1>7 DEF Next

THEOREM Holds == Spec => [][Prop]_vars
  BY InitHolds, StepHolds, PropHolds, PTL DEF Spec
====
